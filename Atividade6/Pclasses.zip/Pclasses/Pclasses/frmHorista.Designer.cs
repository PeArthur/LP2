﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSal = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMat = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.lblSalHora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMat = new System.Windows.Forms.Label();
            this.lblNumFaltas = new System.Windows.Forms.Label();
            this.lblNumHoras = new System.Windows.Forms.Label();
            this.txtNumFaltas = new System.Windows.Forms.TextBox();
            this.txtNumHoras = new System.Windows.Forms.TextBox();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(307, 197);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(99, 20);
            this.txtData.TabIndex = 29;
            // 
            // txtSal
            // 
            this.txtSal.Location = new System.Drawing.Point(309, 135);
            this.txtSal.Name = "txtSal";
            this.txtSal.Size = new System.Drawing.Size(99, 20);
            this.txtSal.TabIndex = 28;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(307, 81);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(340, 20);
            this.txtNome.TabIndex = 27;
            // 
            // txtMat
            // 
            this.txtMat.Location = new System.Drawing.Point(308, 107);
            this.txtMat.Name = "txtMat";
            this.txtMat.Size = new System.Drawing.Size(99, 20);
            this.txtMat.TabIndex = 26;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(148, 207);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(144, 13);
            this.lblData.TabIndex = 25;
            this.lblData.Text = "Data de Entrada na Empresa";
            // 
            // lblSalHora
            // 
            this.lblSalHora.AutoSize = true;
            this.lblSalHora.Location = new System.Drawing.Point(147, 142);
            this.lblSalHora.Name = "lblSalHora";
            this.lblSalHora.Size = new System.Drawing.Size(83, 13);
            this.lblSalHora.TabIndex = 24;
            this.lblSalHora.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(146, 88);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 23;
            this.lblNome.Text = "Nome";
            // 
            // lblMat
            // 
            this.lblMat.AutoSize = true;
            this.lblMat.Location = new System.Drawing.Point(147, 110);
            this.lblMat.Name = "lblMat";
            this.lblMat.Size = new System.Drawing.Size(50, 13);
            this.lblMat.TabIndex = 22;
            this.lblMat.Text = "Matricula";
            // 
            // lblNumFaltas
            // 
            this.lblNumFaltas.AutoSize = true;
            this.lblNumFaltas.Location = new System.Drawing.Point(148, 233);
            this.lblNumFaltas.Name = "lblNumFaltas";
            this.lblNumFaltas.Size = new System.Drawing.Size(90, 13);
            this.lblNumFaltas.TabIndex = 30;
            this.lblNumFaltas.Text = "Numero de Faltas";
            // 
            // lblNumHoras
            // 
            this.lblNumHoras.AutoSize = true;
            this.lblNumHoras.Location = new System.Drawing.Point(147, 178);
            this.lblNumHoras.Name = "lblNumHoras";
            this.lblNumHoras.Size = new System.Drawing.Size(90, 13);
            this.lblNumHoras.TabIndex = 31;
            this.lblNumHoras.Text = "Número de Horas";
            // 
            // txtNumFaltas
            // 
            this.txtNumFaltas.Location = new System.Drawing.Point(307, 223);
            this.txtNumFaltas.Name = "txtNumFaltas";
            this.txtNumFaltas.Size = new System.Drawing.Size(99, 20);
            this.txtNumFaltas.TabIndex = 32;
            // 
            // txtNumHoras
            // 
            this.txtNumHoras.Location = new System.Drawing.Point(307, 171);
            this.txtNumHoras.Name = "txtNumHoras";
            this.txtNumHoras.Size = new System.Drawing.Size(100, 20);
            this.txtNumHoras.TabIndex = 33;
            // 
            // btnIniciar
            // 
            this.btnIniciar.Location = new System.Drawing.Point(307, 291);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(134, 63);
            this.btnIniciar.TabIndex = 34;
            this.btnIniciar.Text = "Iniciar";
            this.btnIniciar.UseVisualStyleBackColor = true;
            this.btnIniciar.Click += new System.EventHandler(this.btnIniciar_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnIniciar);
            this.Controls.Add(this.txtNumHoras);
            this.Controls.Add(this.txtNumFaltas);
            this.Controls.Add(this.lblNumHoras);
            this.Controls.Add(this.lblNumFaltas);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMat);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSalHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMat);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSal;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMat;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblSalHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.Label lblNumFaltas;
        private System.Windows.Forms.Label lblNumHoras;
        private System.Windows.Forms.TextBox txtNumFaltas;
        private System.Windows.Forms.TextBox txtNumHoras;
        private System.Windows.Forms.Button btnIniciar;
    }
}