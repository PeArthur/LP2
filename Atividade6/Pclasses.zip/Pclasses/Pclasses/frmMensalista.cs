﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnsem_Click(object sender, EventArgs e)
        {
            Mensalista objeMenslista = new Mensalista();

            objeMenslista.NomeEmpregado = txtNome.Text;
            objeMenslista.Matricula = Convert.ToInt32(txtMat.Text);
            objeMenslista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objeMenslista.SalarioMensal = Convert.ToDouble(txtSal.Text);

            MessageBox.Show("Nome = " + objeMenslista.NomeEmpregado + "\n" + 
                "Matricula = " + objeMenslista.Matricula + "\n" + 
                "Tempo Trabalho: " + objeMenslista.TempoTrabalho() + "\n" + 
                "Salario Final= " + objeMenslista.SalarioBruto().ToString("N2"));

            //static
            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMat.Text), txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSal.Text));

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                "Matricula = " + objMensalista.Matricula + "\n" +
                "Tempo Trabalho: " + objMensalista.TempoTrabalho() + "\n" +
                "Salario Final= " + objMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
