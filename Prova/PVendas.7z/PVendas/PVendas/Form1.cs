﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            int N = 2;
            double[,] MesSalario = new double[N,4];
            double totMes = 0, total = 0;
            string retorno = "";
            string aux;
            

            for (int i = 0; i < N; i++)
            {
                lstbxMesSalario.Items.Add($"======= Mês {i + 1} =======");
                for (int j = 0; j < 4; j++) 
                {

                    aux = Interaction.InputBox($"Número mês: {i + 1}, Número semana: {j + 1}");
                    if (double.TryParse(aux, out MesSalario[i, j]))
                    {
                        if (MesSalario[i, j] < 0)
                        {
                            MessageBox.Show("Informe valores maiores que 0.");
                            j--;
                        }

                        else
                        {
                            retorno = $"\nMês {i + 1}, Semana {j + 1} = {(MesSalario[i, j].ToString("N2"))}";
                            totMes = totMes + MesSalario[i, j];
                            lstbxMesSalario.Items.Add(retorno);
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Informe valores válidos.");
                        j--;
                    }
                }
                total = total + totMes;
                retorno = $"Total Mes= R${totMes.ToString("C2")}";
                lstbxMesSalario.Items.Add(retorno);

            }
            lstbxMesSalario.Items.Add($"==========================");
            retorno = $"Total: {total.ToString("C2")}";
            lstbxMesSalario.Items.Add(retorno);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstbxMesSalario.Items.Clear();
        }
    }
}
