﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double SalarioB, SalarioL, SalarioF, NumFilhos, AliINSS, AliIRPF, DescINSS, DescIRPF;

        private void txtName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            NupFilhos.Text = "";
            mskbxSal.Text = "";
            txtAINSS.Text = "";
            txtAIRPF.Text = "";
            txtDescINSS.Text = "";
            txtDescIRPF.Text = "";
            txtSalFamilia.Text = "";
            txtSalLiquid.Text = "";
            txtName.Focus();
        }

    

        private void btnValidar_Click(object sender, EventArgs e)
        {
            //INSS
            DescINSS = 0;
           
            if (SalarioB <= 800.47)
            {
                DescINSS = SalarioB * 0.0765;
                txtAINSS.Text = "7,65%";
                txtDescINSS.Text = DescINSS.ToString();
            }
            else if (SalarioB > 800.47 && SalarioB <= 1050)
            {
                DescINSS = SalarioB * 0.0865;
                txtAINSS.Text = "8,65%";
                txtDescINSS.Text = DescINSS.ToString();
            }
            else if (SalarioB > 1050 && SalarioB <= 1400.77)
            {
                DescINSS = SalarioB * 0.09;
                txtAINSS.Text = "9%";
                txtDescINSS.Text = DescINSS.ToString();
            }
            else if (SalarioB > 1400.77 && SalarioB <= 2801.56)
            {
                DescINSS = SalarioB * 0.11;
                txtAINSS.Text = "11%";
                txtDescINSS.Text = DescINSS.ToString();
            }
            else
            {
                DescINSS = SalarioB - 308.17;
                txtAINSS.Text = "308,17";
                txtDescINSS.Text = DescINSS.ToString();
                
            }

            //IRPF
            DescIRPF = 0;
            if (SalarioB <= 1257.12)
            {
                DescIRPF = 0;
                txtAIRPF.Text = "Isento";
                txtDescIRPF.Text = DescIRPF.ToString();

            }
            else if (SalarioB > 2512.08)
            {
                DescIRPF = SalarioB*0.275;
                txtAIRPF.Text = "27,5%";
                txtDescIRPF.Text = DescIRPF.ToString();
            }
            else
            {
                DescIRPF = SalarioB*0.15;
                txtAIRPF.Text = "15%";
                txtDescIRPF.Text = DescIRPF.ToString();
            }

            //Família
            if(SalarioB <= 435.52)
            {
                SalarioF = SalarioB + (22.33 * NumFilhos);
                txtSalFamilia.Text = SalarioF.ToString();
            }
            else if(SalarioB > 654.61)
            {
                txtSalFamilia.Text = "0";
            }
            else
            {
                SalarioF = SalarioB + (15.74 * NumFilhos);
                txtSalFamilia.Text = SalarioF.ToString();
            }

            SalarioL = SalarioB - DescINSS - DescINSS + SalarioF;
            txtSalLiquid.Text = SalarioL.ToString();
        }




        private void NupFilhos_ValueChanged(object sender, EventArgs e)
        {
            NumFilhos = Convert.ToDouble(NumFilhos);

        }

        private void mskbxSal_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSal.Text, out SalarioB))
            {
                MessageBox.Show("Favor colocar apenas números!");
                mskbxSal.Focus();

            }
        }
    }
}
