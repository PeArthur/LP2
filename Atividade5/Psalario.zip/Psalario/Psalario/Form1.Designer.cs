﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAINSS = new System.Windows.Forms.Label();
            this.lblAIRPF = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblSalLiquid = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAINSS = new System.Windows.Forms.TextBox();
            this.txtAIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquid = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.mskbxSal = new System.Windows.Forms.MaskedTextBox();
            this.NupFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnValidar = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(80, 71);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(168, 23);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Nome Funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(79, 126);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(123, 23);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(79, 190);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(169, 23);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Números de Filhos";
            // 
            // lblAINSS
            // 
            this.lblAINSS.AutoSize = true;
            this.lblAINSS.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAINSS.Location = new System.Drawing.Point(80, 368);
            this.lblAINSS.Name = "lblAINSS";
            this.lblAINSS.Size = new System.Drawing.Size(131, 23);
            this.lblAINSS.TabIndex = 3;
            this.lblAINSS.Text = "Alíquota INSS";
            // 
            // lblAIRPF
            // 
            this.lblAIRPF.AutoSize = true;
            this.lblAIRPF.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAIRPF.Location = new System.Drawing.Point(80, 416);
            this.lblAIRPF.Name = "lblAIRPF";
            this.lblAIRPF.Size = new System.Drawing.Size(132, 23);
            this.lblAIRPF.TabIndex = 4;
            this.lblAIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFam.Location = new System.Drawing.Point(80, 465);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(138, 23);
            this.lblSalFam.TabIndex = 5;
            this.lblSalFam.Text = "Salário Família";
            // 
            // lblSalLiquid
            // 
            this.lblSalLiquid.AutoSize = true;
            this.lblSalLiquid.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiquid.Location = new System.Drawing.Point(637, 367);
            this.lblSalLiquid.Name = "lblSalLiquid";
            this.lblSalLiquid.Size = new System.Drawing.Size(140, 23);
            this.lblSalLiquid.TabIndex = 6;
            this.lblSalLiquid.Text = "Salário Líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescINSS.Location = new System.Drawing.Point(637, 415);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(137, 23);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIRPF.Location = new System.Drawing.Point(637, 464);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(138, 23);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(255, 71);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(566, 20);
            this.txtName.TabIndex = 9;
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress_1);
            // 
            // txtAINSS
            // 
            this.txtAINSS.Enabled = false;
            this.txtAINSS.Location = new System.Drawing.Point(233, 371);
            this.txtAINSS.Name = "txtAINSS";
            this.txtAINSS.Size = new System.Drawing.Size(213, 20);
            this.txtAINSS.TabIndex = 10;
            // 
            // txtAIRPF
            // 
            this.txtAIRPF.Enabled = false;
            this.txtAIRPF.Location = new System.Drawing.Point(233, 415);
            this.txtAIRPF.Name = "txtAIRPF";
            this.txtAIRPF.Size = new System.Drawing.Size(213, 20);
            this.txtAIRPF.TabIndex = 11;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(233, 468);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(213, 20);
            this.txtSalFamilia.TabIndex = 12;
            // 
            // txtSalLiquid
            // 
            this.txtSalLiquid.Enabled = false;
            this.txtSalLiquid.Location = new System.Drawing.Point(815, 372);
            this.txtSalLiquid.Name = "txtSalLiquid";
            this.txtSalLiquid.Size = new System.Drawing.Size(241, 20);
            this.txtSalLiquid.TabIndex = 13;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(815, 416);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(241, 20);
            this.txtDescINSS.TabIndex = 14;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(815, 469);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(241, 20);
            this.txtDescIRPF.TabIndex = 15;
            // 
            // mskbxSal
            // 
            this.mskbxSal.Location = new System.Drawing.Point(255, 130);
            this.mskbxSal.Mask = "990000.00";
            this.mskbxSal.Name = "mskbxSal";
            this.mskbxSal.Size = new System.Drawing.Size(191, 20);
            this.mskbxSal.TabIndex = 16;
            this.mskbxSal.Validated += new System.EventHandler(this.mskbxSal_Validated);
            // 
            // NupFilhos
            // 
            this.NupFilhos.Location = new System.Drawing.Point(255, 193);
            this.NupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NupFilhos.Name = "NupFilhos";
            this.NupFilhos.Size = new System.Drawing.Size(76, 20);
            this.NupFilhos.TabIndex = 17;
            this.NupFilhos.ValueChanged += new System.EventHandler(this.NupFilhos_ValueChanged);
            // 
            // btnValidar
            // 
            this.btnValidar.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidar.Location = new System.Drawing.Point(255, 267);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(151, 52);
            this.btnValidar.TabIndex = 18;
            this.btnValidar.Text = "Validar Dados";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(526, 267);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(119, 52);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 637);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnValidar);
            this.Controls.Add(this.NupFilhos);
            this.Controls.Add(this.mskbxSal);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquid);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAIRPF);
            this.Controls.Add(this.txtAINSS);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiquid);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblAIRPF);
            this.Controls.Add(this.lblAINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblName);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAINSS;
        private System.Windows.Forms.Label lblAIRPF;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblSalLiquid;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAINSS;
        private System.Windows.Forms.TextBox txtAIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquid;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSal;
        private System.Windows.Forms.NumericUpDown NupFilhos;
        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.Button btnClear;
    }
}

