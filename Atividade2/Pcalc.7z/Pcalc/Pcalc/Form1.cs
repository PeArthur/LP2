﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
     public partial class Form1 : Form
    {
        double vlr1, vlr2, result;

        public Form1()
        {
            InitializeComponent();
        }
        
        private void btnMpy_Click(object sender, EventArgs e)
        {
            result = vlr1 * vlr2;
            txtResult.Text = result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (vlr2 == 0)
            {
                MessageBox.Show("Impossível dividir por 0!");
                txtNum2.Focus();
            }
            else
            {
                result = vlr1 / vlr2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out vlr1))
            {
                MessageBox.Show("Favor colocar apenas números!");
                txtNum1.Focus();

            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out vlr2))
            {
                MessageBox.Show("Favor colocar apenas números!");
                txtNum2.Focus();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResult.Text = "";
        }
               
        private void btnAdd_Click(object sender, EventArgs e)
        {
            result = vlr1 + vlr2;
            txtResult.Text = result.ToString();
        }
        private void btnSub_Click(object sender, EventArgs e)
        {
            result = vlr1 - vlr2;
            txtResult.Text = result.ToString();
        }

    }
        
}
